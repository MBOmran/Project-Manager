﻿
namespace TelerikWinFormsApp1
{
    partial class RadForm1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(RadForm1));
            Telerik.WinControls.UI.SchedulerDailyPrintStyle schedulerDailyPrintStyle1 = new Telerik.WinControls.UI.SchedulerDailyPrintStyle();
            this.radPageView1 = new Telerik.WinControls.UI.RadPageView();
            this.ProjectsPage = new Telerik.WinControls.UI.RadPageViewPage();
            this.radDataLayout1 = new Telerik.WinControls.UI.RadDataLayout();
            this.radSeparator1 = new Telerik.WinControls.UI.RadSeparator();
            this.radButton3 = new Telerik.WinControls.UI.RadButton();
            this.radBindingNavigator1 = new Telerik.WinControls.UI.RadBindingNavigator();
            this.radButton1 = new Telerik.WinControls.UI.RadButton();
            this.radBindingNavigator1RowElement = new Telerik.WinControls.UI.CommandBarRowElement();
            this.radBindingNavigator1FirstStrip = new Telerik.WinControls.UI.CommandBarStripElement();
            this.radBindingNavigator1MoveFirstItem = new Telerik.WinControls.UI.CommandBarButton();
            this.commandBarSeparator1 = new Telerik.WinControls.UI.CommandBarSeparator();
            this.radBindingNavigator1MovePreviousItem = new Telerik.WinControls.UI.CommandBarButton();
            this.commandBarSeparator2 = new Telerik.WinControls.UI.CommandBarSeparator();
            this.radBindingNavigator1PositionItem = new Telerik.WinControls.UI.CommandBarTextBox();
            this.radBindingNavigator1CountItem = new Telerik.WinControls.UI.CommandBarLabel();
            this.commandBarSeparator3 = new Telerik.WinControls.UI.CommandBarSeparator();
            this.radBindingNavigator1MoveNextItem = new Telerik.WinControls.UI.CommandBarButton();
            this.commandBarSeparator4 = new Telerik.WinControls.UI.CommandBarSeparator();
            this.radBindingNavigator1MoveLastItem = new Telerik.WinControls.UI.CommandBarButton();
            this.radBindingNavigator1SecondStrip = new Telerik.WinControls.UI.CommandBarStripElement();
            this.radBindingNavigator1AddNewItem = new Telerik.WinControls.UI.CommandBarButton();
            this.commandBarSeparator5 = new Telerik.WinControls.UI.CommandBarSeparator();
            this.radBindingNavigator1DeleteItem = new Telerik.WinControls.UI.CommandBarButton();
            this.radButton2 = new Telerik.WinControls.UI.RadButton();
            this.Scheduler = new Telerik.WinControls.UI.RadPageViewPage();
            this.radScheduler1 = new Telerik.WinControls.UI.RadScheduler();
            this.radSchedulerNavigator1 = new Telerik.WinControls.UI.RadSchedulerNavigator();
            this.ToDoList = new Telerik.WinControls.UI.RadPageViewPage();
            this.radTextBox2 = new Telerik.WinControls.UI.RadTextBox();
            this.button7 = new System.Windows.Forms.Button();
            this.radTextBox1 = new Telerik.WinControls.UI.RadTextBox();
            this.radioButton2 = new System.Windows.Forms.RadioButton();
            this.radioButton1 = new System.Windows.Forms.RadioButton();
            this.label5 = new System.Windows.Forms.Label();
            this.button6 = new System.Windows.Forms.Button();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.button5 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.cmbPriority = new System.Windows.Forms.ComboBox();
            this.tbTaskDescription = new System.Windows.Forms.TextBox();
            this.tbTaskName = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.Team = new Telerik.WinControls.UI.RadPageViewPage();
            this.radDataLayout2 = new Telerik.WinControls.UI.RadDataLayout();
            this.radBindingNavigator2 = new Telerik.WinControls.UI.RadBindingNavigator();
            this.radBindingNavigator2RowElement = new Telerik.WinControls.UI.CommandBarRowElement();
            this.radBindingNavigator2FirstStrip = new Telerik.WinControls.UI.CommandBarStripElement();
            this.radBindingNavigator2MoveFirstItem = new Telerik.WinControls.UI.CommandBarButton();
            this.commandBarSeparator6 = new Telerik.WinControls.UI.CommandBarSeparator();
            this.radBindingNavigator2MovePreviousItem = new Telerik.WinControls.UI.CommandBarButton();
            this.commandBarSeparator7 = new Telerik.WinControls.UI.CommandBarSeparator();
            this.radBindingNavigator2PositionItem = new Telerik.WinControls.UI.CommandBarTextBox();
            this.radBindingNavigator2CountItem = new Telerik.WinControls.UI.CommandBarLabel();
            this.commandBarSeparator8 = new Telerik.WinControls.UI.CommandBarSeparator();
            this.radBindingNavigator2MoveNextItem = new Telerik.WinControls.UI.CommandBarButton();
            this.commandBarSeparator9 = new Telerik.WinControls.UI.CommandBarSeparator();
            this.radBindingNavigator2MoveLastItem = new Telerik.WinControls.UI.CommandBarButton();
            this.radBindingNavigator2SecondStrip = new Telerik.WinControls.UI.CommandBarStripElement();
            this.radBindingNavigator2AddNewItem = new Telerik.WinControls.UI.CommandBarButton();
            this.commandBarSeparator10 = new Telerik.WinControls.UI.CommandBarSeparator();
            this.radBindingNavigator2DeleteItem = new Telerik.WinControls.UI.CommandBarButton();
            this.layoutControlItem2 = new Telerik.WinControls.UI.LayoutControlItem();
            this.radButton4 = new Telerik.WinControls.UI.RadButton();
            this.radButton6 = new Telerik.WinControls.UI.RadButton();
            this.TitleBar1 = new Telerik.WinControls.UI.RadTitleBar();
            this.object_6543ef47_badb_461b_bfc4_277c159d816a = new Telerik.WinControls.RootRadElement();
            this.bindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.layoutControlItem1 = new Telerik.WinControls.UI.LayoutControlItem();
            this.bindingSource2 = new System.Windows.Forms.BindingSource(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.radPageView1)).BeginInit();
            this.radPageView1.SuspendLayout();
            this.ProjectsPage.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.radDataLayout1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radDataLayout1.LayoutControl)).BeginInit();
            this.radDataLayout1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.radSeparator1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radButton3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radBindingNavigator1)).BeginInit();
            this.radBindingNavigator1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.radButton1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radButton2)).BeginInit();
            this.Scheduler.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.radScheduler1)).BeginInit();
            this.radScheduler1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.radSchedulerNavigator1)).BeginInit();
            this.ToDoList.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.radTextBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radTextBox1)).BeginInit();
            this.Team.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.radDataLayout2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radDataLayout2.LayoutControl)).BeginInit();
            this.radDataLayout2.LayoutControl.SuspendLayout();
            this.radDataLayout2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.radBindingNavigator2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radButton4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radButton6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.TitleBar1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bindingSource2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this)).BeginInit();
            this.SuspendLayout();
            // 
            // radPageView1
            // 
            this.radPageView1.Controls.Add(this.ProjectsPage);
            this.radPageView1.Controls.Add(this.Scheduler);
            this.radPageView1.Controls.Add(this.ToDoList);
            this.radPageView1.Controls.Add(this.Team);
            this.radPageView1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.radPageView1.Location = new System.Drawing.Point(0, 28);
            this.radPageView1.Name = "radPageView1";
            this.radPageView1.SelectedPage = this.ToDoList;
            this.radPageView1.Size = new System.Drawing.Size(1332, 760);
            this.radPageView1.TabIndex = 3;
            this.radPageView1.ThemeName = "ControlDefault";
            this.radPageView1.ViewMode = Telerik.WinControls.UI.PageViewMode.NavigationView;
            // 
            // ProjectsPage
            // 
            this.ProjectsPage.Controls.Add(this.radDataLayout1);
            this.ProjectsPage.Controls.Add(this.radSeparator1);
            this.ProjectsPage.Controls.Add(this.radButton3);
            this.ProjectsPage.Controls.Add(this.radBindingNavigator1);
            this.ProjectsPage.Controls.Add(this.radButton2);
            this.ProjectsPage.ItemSize = new System.Drawing.SizeF(14F, 14F);
            this.ProjectsPage.Location = new System.Drawing.Point(281, 30);
            this.ProjectsPage.Name = "ProjectsPage";
            this.ProjectsPage.Size = new System.Drawing.Size(754, 711);
            this.ProjectsPage.Text = "Projects";
            // 
            // radDataLayout1
            // 
            this.radDataLayout1.Dock = System.Windows.Forms.DockStyle.Fill;
            // 
            // radDataLayout1.LayoutControl
            // 
            this.radDataLayout1.LayoutControl.Dock = System.Windows.Forms.DockStyle.Fill;
            this.radDataLayout1.LayoutControl.DrawBorder = false;
            this.radDataLayout1.LayoutControl.Location = new System.Drawing.Point(0, 0);
            this.radDataLayout1.LayoutControl.Name = "LayoutControl";
            this.radDataLayout1.LayoutControl.Size = new System.Drawing.Size(752, 627);
            this.radDataLayout1.LayoutControl.TabIndex = 0;
            this.radDataLayout1.Location = new System.Drawing.Point(0, 30);
            this.radDataLayout1.Name = "radDataLayout1";
            this.radDataLayout1.Size = new System.Drawing.Size(754, 629);
            this.radDataLayout1.TabIndex = 1;
            // 
            // radSeparator1
            // 
            this.radSeparator1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.radSeparator1.Location = new System.Drawing.Point(0, 659);
            this.radSeparator1.Name = "radSeparator1";
            this.radSeparator1.Size = new System.Drawing.Size(754, 4);
            this.radSeparator1.TabIndex = 6;
            // 
            // radButton3
            // 
            this.radButton3.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.radButton3.Location = new System.Drawing.Point(0, 663);
            this.radButton3.Name = "radButton3";
            this.radButton3.Size = new System.Drawing.Size(754, 24);
            this.radButton3.TabIndex = 5;
            this.radButton3.Text = "Save";
            this.radButton3.Click += new System.EventHandler(this.radButton3_Click);
            // 
            // radBindingNavigator1
            // 
            this.radBindingNavigator1.Controls.Add(this.radButton1);
            this.radBindingNavigator1.Dock = System.Windows.Forms.DockStyle.Top;
            this.radBindingNavigator1.Location = new System.Drawing.Point(0, 0);
            this.radBindingNavigator1.Name = "radBindingNavigator1";
            this.radBindingNavigator1.Rows.AddRange(new Telerik.WinControls.UI.CommandBarRowElement[] {
            this.radBindingNavigator1RowElement});
            this.radBindingNavigator1.Size = new System.Drawing.Size(754, 30);
            this.radBindingNavigator1.TabIndex = 2;
            // 
            // radButton1
            // 
            this.radButton1.Location = new System.Drawing.Point(559, 30);
            this.radButton1.Name = "radButton1";
            this.radButton1.Size = new System.Drawing.Size(110, 24);
            this.radButton1.TabIndex = 1;
            this.radButton1.Text = "radButton1";
            // 
            // radBindingNavigator1RowElement
            // 
            this.radBindingNavigator1RowElement.MinSize = new System.Drawing.Size(25, 25);
            this.radBindingNavigator1RowElement.Name = "radBindingNavigator1RowElement";
            this.radBindingNavigator1RowElement.Strips.AddRange(new Telerik.WinControls.UI.CommandBarStripElement[] {
            this.radBindingNavigator1FirstStrip,
            this.radBindingNavigator1SecondStrip});
            // 
            // radBindingNavigator1FirstStrip
            // 
            this.radBindingNavigator1FirstStrip.DisplayName = "radBindingNavigator1FirstStrip";
            this.radBindingNavigator1FirstStrip.EnableDragging = false;
            // 
            // 
            // 
            this.radBindingNavigator1FirstStrip.Grip.Visibility = Telerik.WinControls.ElementVisibility.Collapsed;
            this.radBindingNavigator1FirstStrip.Items.AddRange(new Telerik.WinControls.UI.RadCommandBarBaseItem[] {
            this.radBindingNavigator1MoveFirstItem,
            this.commandBarSeparator1,
            this.radBindingNavigator1MovePreviousItem,
            this.commandBarSeparator2,
            this.radBindingNavigator1PositionItem,
            this.radBindingNavigator1CountItem,
            this.commandBarSeparator3,
            this.radBindingNavigator1MoveNextItem,
            this.commandBarSeparator4,
            this.radBindingNavigator1MoveLastItem});
            this.radBindingNavigator1FirstStrip.MinSize = new System.Drawing.Size(0, 0);
            // 
            // 
            // 
            this.radBindingNavigator1FirstStrip.OverflowButton.Visibility = Telerik.WinControls.ElementVisibility.Collapsed;
            ((Telerik.WinControls.UI.RadCommandBarGrip)(this.radBindingNavigator1FirstStrip.GetChildAt(0))).Visibility = Telerik.WinControls.ElementVisibility.Collapsed;
            ((Telerik.WinControls.UI.RadCommandBarOverflowButton)(this.radBindingNavigator1FirstStrip.GetChildAt(2))).Visibility = Telerik.WinControls.ElementVisibility.Collapsed;
            // 
            // radBindingNavigator1MoveFirstItem
            // 
            this.radBindingNavigator1MoveFirstItem.Image = ((System.Drawing.Image)(resources.GetObject("radBindingNavigator1MoveFirstItem.Image")));
            this.radBindingNavigator1MoveFirstItem.Margin = new System.Windows.Forms.Padding(3, 0, 0, 0);
            this.radBindingNavigator1MoveFirstItem.Name = "radBindingNavigator1MoveFirstItem";
            // 
            // commandBarSeparator1
            // 
            this.commandBarSeparator1.Name = "commandBarSeparator1";
            this.commandBarSeparator1.VisibleInOverflowMenu = false;
            // 
            // radBindingNavigator1MovePreviousItem
            // 
            this.radBindingNavigator1MovePreviousItem.Image = ((System.Drawing.Image)(resources.GetObject("radBindingNavigator1MovePreviousItem.Image")));
            this.radBindingNavigator1MovePreviousItem.Name = "radBindingNavigator1MovePreviousItem";
            // 
            // commandBarSeparator2
            // 
            this.commandBarSeparator2.Name = "commandBarSeparator2";
            this.commandBarSeparator2.VisibleInOverflowMenu = false;
            // 
            // radBindingNavigator1PositionItem
            // 
            this.radBindingNavigator1PositionItem.Name = "radBindingNavigator1PositionItem";
            // 
            // radBindingNavigator1CountItem
            // 
            this.radBindingNavigator1CountItem.Name = "radBindingNavigator1CountItem";
            this.radBindingNavigator1CountItem.Text = "of {0}";
            // 
            // commandBarSeparator3
            // 
            this.commandBarSeparator3.Name = "commandBarSeparator3";
            this.commandBarSeparator3.VisibleInOverflowMenu = false;
            // 
            // radBindingNavigator1MoveNextItem
            // 
            this.radBindingNavigator1MoveNextItem.Image = ((System.Drawing.Image)(resources.GetObject("radBindingNavigator1MoveNextItem.Image")));
            this.radBindingNavigator1MoveNextItem.Name = "radBindingNavigator1MoveNextItem";
            // 
            // commandBarSeparator4
            // 
            this.commandBarSeparator4.Name = "commandBarSeparator4";
            this.commandBarSeparator4.VisibleInOverflowMenu = false;
            // 
            // radBindingNavigator1MoveLastItem
            // 
            this.radBindingNavigator1MoveLastItem.Image = ((System.Drawing.Image)(resources.GetObject("radBindingNavigator1MoveLastItem.Image")));
            this.radBindingNavigator1MoveLastItem.Name = "radBindingNavigator1MoveLastItem";
            // 
            // radBindingNavigator1SecondStrip
            // 
            this.radBindingNavigator1SecondStrip.DisplayName = "radBindingNavigator1SecondStrip";
            this.radBindingNavigator1SecondStrip.EnableDragging = false;
            // 
            // 
            // 
            this.radBindingNavigator1SecondStrip.Grip.Visibility = Telerik.WinControls.ElementVisibility.Collapsed;
            this.radBindingNavigator1SecondStrip.Items.AddRange(new Telerik.WinControls.UI.RadCommandBarBaseItem[] {
            this.radBindingNavigator1AddNewItem,
            this.commandBarSeparator5,
            this.radBindingNavigator1DeleteItem});
            this.radBindingNavigator1SecondStrip.MinSize = new System.Drawing.Size(0, 0);
            // 
            // 
            // 
            this.radBindingNavigator1SecondStrip.OverflowButton.Visibility = Telerik.WinControls.ElementVisibility.Collapsed;
            ((Telerik.WinControls.UI.RadCommandBarGrip)(this.radBindingNavigator1SecondStrip.GetChildAt(0))).Visibility = Telerik.WinControls.ElementVisibility.Collapsed;
            ((Telerik.WinControls.UI.RadCommandBarOverflowButton)(this.radBindingNavigator1SecondStrip.GetChildAt(2))).Visibility = Telerik.WinControls.ElementVisibility.Collapsed;
            // 
            // radBindingNavigator1AddNewItem
            // 
            this.radBindingNavigator1AddNewItem.Image = ((System.Drawing.Image)(resources.GetObject("radBindingNavigator1AddNewItem.Image")));
            this.radBindingNavigator1AddNewItem.Margin = new System.Windows.Forms.Padding(3, 0, 0, 0);
            this.radBindingNavigator1AddNewItem.Name = "radBindingNavigator1AddNewItem";
            // 
            // commandBarSeparator5
            // 
            this.commandBarSeparator5.Name = "commandBarSeparator5";
            this.commandBarSeparator5.VisibleInOverflowMenu = false;
            // 
            // radBindingNavigator1DeleteItem
            // 
            this.radBindingNavigator1DeleteItem.Image = ((System.Drawing.Image)(resources.GetObject("radBindingNavigator1DeleteItem.Image")));
            this.radBindingNavigator1DeleteItem.Name = "radBindingNavigator1DeleteItem";
            // 
            // radButton2
            // 
            this.radButton2.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.radButton2.Location = new System.Drawing.Point(0, 687);
            this.radButton2.Name = "radButton2";
            this.radButton2.Size = new System.Drawing.Size(754, 24);
            this.radButton2.TabIndex = 4;
            this.radButton2.Text = "Load";
            this.radButton2.Click += new System.EventHandler(this.radButton2_Click);
            // 
            // Scheduler
            // 
            this.Scheduler.Controls.Add(this.radScheduler1);
            this.Scheduler.ItemSize = new System.Drawing.SizeF(14F, 14F);
            this.Scheduler.Location = new System.Drawing.Point(281, 30);
            this.Scheduler.Name = "Scheduler";
            this.Scheduler.Size = new System.Drawing.Size(754, 711);
            this.Scheduler.Text = "Scheduler";
            // 
            // radScheduler1
            // 
            this.radScheduler1.Controls.Add(this.radSchedulerNavigator1);
            this.radScheduler1.Culture = new System.Globalization.CultureInfo("en-US");
            this.radScheduler1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.radScheduler1.Location = new System.Drawing.Point(0, 0);
            this.radScheduler1.Name = "radScheduler1";
            schedulerDailyPrintStyle1.AppointmentFont = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            schedulerDailyPrintStyle1.DateEndRange = new System.DateTime(2024, 4, 30, 0, 0, 0, 0);
            schedulerDailyPrintStyle1.DateHeadingFont = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold);
            schedulerDailyPrintStyle1.DateStartRange = new System.DateTime(2024, 4, 25, 0, 0, 0, 0);
            schedulerDailyPrintStyle1.PageHeadingFont = new System.Drawing.Font("Microsoft Sans Serif", 22F, System.Drawing.FontStyle.Bold);
            this.radScheduler1.PrintStyle = schedulerDailyPrintStyle1;
            this.radScheduler1.Size = new System.Drawing.Size(754, 711);
            this.radScheduler1.TabIndex = 0;
            // 
            // radSchedulerNavigator1
            // 
            this.radSchedulerNavigator1.AssociatedScheduler = null;
            this.radSchedulerNavigator1.DateFormat = "yyyy/MM/dd";
            this.radSchedulerNavigator1.Dock = System.Windows.Forms.DockStyle.Top;
            this.radSchedulerNavigator1.Location = new System.Drawing.Point(0, 0);
            this.radSchedulerNavigator1.Name = "radSchedulerNavigator1";
            this.radSchedulerNavigator1.NavigationStepType = Telerik.WinControls.UI.NavigationStepTypes.Day;
            // 
            // 
            // 
            this.radSchedulerNavigator1.RootElement.StretchVertically = false;
            this.radSchedulerNavigator1.Size = new System.Drawing.Size(754, 0);
            this.radSchedulerNavigator1.TabIndex = 0;
            // 
            // ToDoList
            // 
            this.ToDoList.Controls.Add(this.radTextBox2);
            this.ToDoList.Controls.Add(this.button7);
            this.ToDoList.Controls.Add(this.radTextBox1);
            this.ToDoList.Controls.Add(this.radioButton2);
            this.ToDoList.Controls.Add(this.radioButton1);
            this.ToDoList.Controls.Add(this.label5);
            this.ToDoList.Controls.Add(this.button6);
            this.ToDoList.Controls.Add(this.textBox3);
            this.ToDoList.Controls.Add(this.button5);
            this.ToDoList.Controls.Add(this.button4);
            this.ToDoList.Controls.Add(this.button3);
            this.ToDoList.Controls.Add(this.button2);
            this.ToDoList.Controls.Add(this.button1);
            this.ToDoList.Controls.Add(this.dateTimePicker1);
            this.ToDoList.Controls.Add(this.cmbPriority);
            this.ToDoList.Controls.Add(this.tbTaskDescription);
            this.ToDoList.Controls.Add(this.tbTaskName);
            this.ToDoList.Controls.Add(this.label4);
            this.ToDoList.Controls.Add(this.label3);
            this.ToDoList.Controls.Add(this.label2);
            this.ToDoList.Controls.Add(this.label1);
            this.ToDoList.ItemSize = new System.Drawing.SizeF(14F, 14F);
            this.ToDoList.Location = new System.Drawing.Point(41, 30);
            this.ToDoList.Name = "ToDoList";
            this.ToDoList.Size = new System.Drawing.Size(1290, 729);
            this.ToDoList.Text = "ToDoList";
            // 
            // radTextBox2
            // 
            this.radTextBox2.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.radTextBox2.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.radTextBox2.Location = new System.Drawing.Point(879, 617);
            this.radTextBox2.Name = "radTextBox2";
            this.radTextBox2.Size = new System.Drawing.Size(151, 20);
            this.radTextBox2.TabIndex = 20;
            this.radTextBox2.TextChanged += new System.EventHandler(this.radTextBox2_TextChanged);
            // 
            // button7
            // 
            this.button7.AutoSize = true;
            this.button7.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.button7.Font = new System.Drawing.Font("Segoe UI Semibold", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button7.Location = new System.Drawing.Point(879, 576);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(151, 35);
            this.button7.TabIndex = 19;
            this.button7.Text = "Find Task By ID";
            this.button7.UseVisualStyleBackColor = true;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // radTextBox1
            // 
            this.radTextBox1.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.radTextBox1.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.radTextBox1.Location = new System.Drawing.Point(637, 617);
            this.radTextBox1.Name = "radTextBox1";
            this.radTextBox1.Size = new System.Drawing.Size(183, 20);
            this.radTextBox1.TabIndex = 18;
            this.radTextBox1.TextChanged += new System.EventHandler(this.radTextBox1_TextChanged);
            // 
            // radioButton2
            // 
            this.radioButton2.AutoSize = true;
            this.radioButton2.Font = new System.Drawing.Font("Segoe UI Semibold", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButton2.Location = new System.Drawing.Point(252, 526);
            this.radioButton2.Name = "radioButton2";
            this.radioButton2.Size = new System.Drawing.Size(60, 34);
            this.radioButton2.TabIndex = 17;
            this.radioButton2.TabStop = true;
            this.radioButton2.Text = "No";
            this.radioButton2.UseVisualStyleBackColor = true;
            // 
            // radioButton1
            // 
            this.radioButton1.AutoSize = true;
            this.radioButton1.Font = new System.Drawing.Font("Segoe UI Semibold", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButton1.Location = new System.Drawing.Point(167, 526);
            this.radioButton1.Name = "radioButton1";
            this.radioButton1.Size = new System.Drawing.Size(61, 34);
            this.radioButton1.TabIndex = 16;
            this.radioButton1.TabStop = true;
            this.radioButton1.Text = "Yes";
            this.radioButton1.UseVisualStyleBackColor = true;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(25, 535);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(94, 21);
            this.label5.TabIndex = 15;
            this.label5.Text = "Completed";
            // 
            // button6
            // 
            this.button6.Location = new System.Drawing.Point(667, 526);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(75, 23);
            this.button6.TabIndex = 14;
            this.button6.Text = "Hide";
            this.button6.UseVisualStyleBackColor = true;
            this.button6.Visible = false;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // textBox3
            // 
            this.textBox3.Font = new System.Drawing.Font("Andalus", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox3.ForeColor = System.Drawing.SystemColors.WindowText;
            this.textBox3.Location = new System.Drawing.Point(374, 226);
            this.textBox3.Multiline = true;
            this.textBox3.Name = "textBox3";
            this.textBox3.ReadOnly = true;
            this.textBox3.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.textBox3.Size = new System.Drawing.Size(580, 294);
            this.textBox3.TabIndex = 13;
            this.textBox3.Visible = false;
            // 
            // button5
            // 
            this.button5.AutoSize = true;
            this.button5.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.button5.Font = new System.Drawing.Font("Segoe UI Semibold", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button5.Location = new System.Drawing.Point(637, 576);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(183, 35);
            this.button5.TabIndex = 12;
            this.button5.Text = "Find Task By Name";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // button4
            // 
            this.button4.AutoSize = true;
            this.button4.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.button4.Font = new System.Drawing.Font("Segoe UI Semibold", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button4.Location = new System.Drawing.Point(350, 576);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(215, 35);
            this.button4.TabIndex = 11;
            this.button4.Text = "Remove Task By Name";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // button3
            // 
            this.button3.AutoSize = true;
            this.button3.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.button3.Font = new System.Drawing.Font("Segoe UI Semibold", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.Location = new System.Drawing.Point(762, 41);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(140, 35);
            this.button3.TabIndex = 10;
            this.button3.Text = "Load All Tasks";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button2
            // 
            this.button2.AutoSize = true;
            this.button2.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.button2.Font = new System.Drawing.Font("Segoe UI Semibold", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.Location = new System.Drawing.Point(578, 41);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(139, 35);
            this.button2.TabIndex = 9;
            this.button2.Text = "Save All Tasks";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button1
            // 
            this.button1.AutoSize = true;
            this.button1.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.button1.Font = new System.Drawing.Font("Segoe UI Semibold", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(167, 576);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(98, 35);
            this.button1.TabIndex = 8;
            this.button1.Text = "Add Task";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimePicker1.Location = new System.Drawing.Point(167, 227);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(200, 25);
            this.dateTimePicker1.TabIndex = 7;
            // 
            // cmbPriority
            // 
            this.cmbPriority.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbPriority.FormattingEnabled = true;
            this.cmbPriority.Items.AddRange(new object[] {
            "High",
            "Medium",
            "Low"});
            this.cmbPriority.Location = new System.Drawing.Point(167, 429);
            this.cmbPriority.Name = "cmbPriority";
            this.cmbPriority.Size = new System.Drawing.Size(121, 29);
            this.cmbPriority.TabIndex = 6;
            // 
            // tbTaskDescription
            // 
            this.tbTaskDescription.Font = new System.Drawing.Font("Segoe UI Semibold", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbTaskDescription.Location = new System.Drawing.Point(167, 80);
            this.tbTaskDescription.Multiline = true;
            this.tbTaskDescription.Name = "tbTaskDescription";
            this.tbTaskDescription.Size = new System.Drawing.Size(335, 119);
            this.tbTaskDescription.TabIndex = 5;
            // 
            // tbTaskName
            // 
            this.tbTaskName.Location = new System.Drawing.Point(167, 30);
            this.tbTaskName.Name = "tbTaskName";
            this.tbTaskName.Size = new System.Drawing.Size(100, 20);
            this.tbTaskName.TabIndex = 4;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(25, 429);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(67, 21);
            this.label4.TabIndex = 3;
            this.label4.Text = "Priority";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(25, 226);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(81, 21);
            this.label3.TabIndex = 2;
            this.label3.Text = "Due Date";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(25, 127);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(135, 21);
            this.label2.TabIndex = 1;
            this.label2.Text = "Task Description";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(25, 27);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(93, 21);
            this.label1.TabIndex = 0;
            this.label1.Text = "Task Name";
            // 
            // Team
            // 
            this.Team.Controls.Add(this.radDataLayout2);
            this.Team.Controls.Add(this.radButton4);
            this.Team.Controls.Add(this.radButton6);
            this.Team.ItemSize = new System.Drawing.SizeF(14F, 14F);
            this.Team.Location = new System.Drawing.Point(281, 30);
            this.Team.Name = "Team";
            this.Team.Size = new System.Drawing.Size(754, 711);
            this.Team.Text = "Team";
            // 
            // radDataLayout2
            // 
            this.radDataLayout2.Dock = System.Windows.Forms.DockStyle.Fill;
            // 
            // radDataLayout2.LayoutControl
            // 
            this.radDataLayout2.LayoutControl.Controls.Add(this.radBindingNavigator2);
            this.radDataLayout2.LayoutControl.Dock = System.Windows.Forms.DockStyle.Fill;
            this.radDataLayout2.LayoutControl.DrawBorder = false;
            this.radDataLayout2.LayoutControl.Items.AddRange(new Telerik.WinControls.RadItem[] {
            this.layoutControlItem2});
            this.radDataLayout2.LayoutControl.Location = new System.Drawing.Point(0, 0);
            this.radDataLayout2.LayoutControl.Name = "LayoutControl";
            this.radDataLayout2.LayoutControl.Size = new System.Drawing.Size(752, 661);
            this.radDataLayout2.LayoutControl.TabIndex = 0;
            this.radDataLayout2.Location = new System.Drawing.Point(0, 0);
            this.radDataLayout2.Name = "radDataLayout2";
            this.radDataLayout2.Size = new System.Drawing.Size(754, 663);
            this.radDataLayout2.TabIndex = 9;
            // 
            // radBindingNavigator2
            // 
            this.radBindingNavigator2.Dock = System.Windows.Forms.DockStyle.Top;
            this.radBindingNavigator2.Location = new System.Drawing.Point(0, 0);
            this.radBindingNavigator2.Name = "radBindingNavigator2";
            this.radBindingNavigator2.Rows.AddRange(new Telerik.WinControls.UI.CommandBarRowElement[] {
            this.radBindingNavigator2RowElement});
            this.radBindingNavigator2.Size = new System.Drawing.Size(752, 0);
            this.radBindingNavigator2.TabIndex = 3;
            // 
            // radBindingNavigator2RowElement
            // 
            this.radBindingNavigator2RowElement.MinSize = new System.Drawing.Size(25, 25);
            this.radBindingNavigator2RowElement.Name = "radBindingNavigator2RowElement";
            this.radBindingNavigator2RowElement.Strips.AddRange(new Telerik.WinControls.UI.CommandBarStripElement[] {
            this.radBindingNavigator2FirstStrip,
            this.radBindingNavigator2SecondStrip});
            // 
            // radBindingNavigator2FirstStrip
            // 
            this.radBindingNavigator2FirstStrip.DisplayName = "radBindingNavigator2FirstStrip";
            this.radBindingNavigator2FirstStrip.EnableDragging = false;
            // 
            // 
            // 
            this.radBindingNavigator2FirstStrip.Grip.Visibility = Telerik.WinControls.ElementVisibility.Collapsed;
            this.radBindingNavigator2FirstStrip.Items.AddRange(new Telerik.WinControls.UI.RadCommandBarBaseItem[] {
            this.radBindingNavigator2MoveFirstItem,
            this.commandBarSeparator6,
            this.radBindingNavigator2MovePreviousItem,
            this.commandBarSeparator7,
            this.radBindingNavigator2PositionItem,
            this.radBindingNavigator2CountItem,
            this.commandBarSeparator8,
            this.radBindingNavigator2MoveNextItem,
            this.commandBarSeparator9,
            this.radBindingNavigator2MoveLastItem});
            this.radBindingNavigator2FirstStrip.MinSize = new System.Drawing.Size(0, 0);
            // 
            // 
            // 
            this.radBindingNavigator2FirstStrip.OverflowButton.Visibility = Telerik.WinControls.ElementVisibility.Collapsed;
            ((Telerik.WinControls.UI.RadCommandBarGrip)(this.radBindingNavigator2FirstStrip.GetChildAt(0))).Visibility = Telerik.WinControls.ElementVisibility.Collapsed;
            ((Telerik.WinControls.UI.RadCommandBarOverflowButton)(this.radBindingNavigator2FirstStrip.GetChildAt(2))).Visibility = Telerik.WinControls.ElementVisibility.Collapsed;
            // 
            // radBindingNavigator2MoveFirstItem
            // 
            this.radBindingNavigator2MoveFirstItem.Image = ((System.Drawing.Image)(resources.GetObject("radBindingNavigator2MoveFirstItem.Image")));
            this.radBindingNavigator2MoveFirstItem.Margin = new System.Windows.Forms.Padding(3, 0, 0, 0);
            this.radBindingNavigator2MoveFirstItem.Name = "radBindingNavigator2MoveFirstItem";
            // 
            // commandBarSeparator6
            // 
            this.commandBarSeparator6.Name = "commandBarSeparator6";
            this.commandBarSeparator6.VisibleInOverflowMenu = false;
            // 
            // radBindingNavigator2MovePreviousItem
            // 
            this.radBindingNavigator2MovePreviousItem.Image = ((System.Drawing.Image)(resources.GetObject("radBindingNavigator2MovePreviousItem.Image")));
            this.radBindingNavigator2MovePreviousItem.Name = "radBindingNavigator2MovePreviousItem";
            // 
            // commandBarSeparator7
            // 
            this.commandBarSeparator7.Name = "commandBarSeparator7";
            this.commandBarSeparator7.VisibleInOverflowMenu = false;
            // 
            // radBindingNavigator2PositionItem
            // 
            this.radBindingNavigator2PositionItem.Name = "radBindingNavigator2PositionItem";
            // 
            // radBindingNavigator2CountItem
            // 
            this.radBindingNavigator2CountItem.Name = "radBindingNavigator2CountItem";
            this.radBindingNavigator2CountItem.Text = "of {0}";
            // 
            // commandBarSeparator8
            // 
            this.commandBarSeparator8.Name = "commandBarSeparator8";
            this.commandBarSeparator8.VisibleInOverflowMenu = false;
            // 
            // radBindingNavigator2MoveNextItem
            // 
            this.radBindingNavigator2MoveNextItem.Image = ((System.Drawing.Image)(resources.GetObject("radBindingNavigator2MoveNextItem.Image")));
            this.radBindingNavigator2MoveNextItem.Name = "radBindingNavigator2MoveNextItem";
            // 
            // commandBarSeparator9
            // 
            this.commandBarSeparator9.Name = "commandBarSeparator9";
            this.commandBarSeparator9.VisibleInOverflowMenu = false;
            // 
            // radBindingNavigator2MoveLastItem
            // 
            this.radBindingNavigator2MoveLastItem.Image = ((System.Drawing.Image)(resources.GetObject("radBindingNavigator2MoveLastItem.Image")));
            this.radBindingNavigator2MoveLastItem.Name = "radBindingNavigator2MoveLastItem";
            // 
            // radBindingNavigator2SecondStrip
            // 
            this.radBindingNavigator2SecondStrip.DisplayName = "radBindingNavigator2SecondStrip";
            this.radBindingNavigator2SecondStrip.EnableDragging = false;
            // 
            // 
            // 
            this.radBindingNavigator2SecondStrip.Grip.Visibility = Telerik.WinControls.ElementVisibility.Collapsed;
            this.radBindingNavigator2SecondStrip.Items.AddRange(new Telerik.WinControls.UI.RadCommandBarBaseItem[] {
            this.radBindingNavigator2AddNewItem,
            this.commandBarSeparator10,
            this.radBindingNavigator2DeleteItem});
            this.radBindingNavigator2SecondStrip.MinSize = new System.Drawing.Size(0, 0);
            // 
            // 
            // 
            this.radBindingNavigator2SecondStrip.OverflowButton.Visibility = Telerik.WinControls.ElementVisibility.Collapsed;
            ((Telerik.WinControls.UI.RadCommandBarGrip)(this.radBindingNavigator2SecondStrip.GetChildAt(0))).Visibility = Telerik.WinControls.ElementVisibility.Collapsed;
            ((Telerik.WinControls.UI.RadCommandBarOverflowButton)(this.radBindingNavigator2SecondStrip.GetChildAt(2))).Visibility = Telerik.WinControls.ElementVisibility.Collapsed;
            // 
            // radBindingNavigator2AddNewItem
            // 
            this.radBindingNavigator2AddNewItem.Image = ((System.Drawing.Image)(resources.GetObject("radBindingNavigator2AddNewItem.Image")));
            this.radBindingNavigator2AddNewItem.Margin = new System.Windows.Forms.Padding(3, 0, 0, 0);
            this.radBindingNavigator2AddNewItem.Name = "radBindingNavigator2AddNewItem";
            // 
            // commandBarSeparator10
            // 
            this.commandBarSeparator10.Name = "commandBarSeparator10";
            this.commandBarSeparator10.VisibleInOverflowMenu = false;
            // 
            // radBindingNavigator2DeleteItem
            // 
            this.radBindingNavigator2DeleteItem.Image = ((System.Drawing.Image)(resources.GetObject("radBindingNavigator2DeleteItem.Image")));
            this.radBindingNavigator2DeleteItem.Name = "radBindingNavigator2DeleteItem";
            // 
            // layoutControlItem2
            // 
            this.layoutControlItem2.AssociatedControl = this.radBindingNavigator2;
            this.layoutControlItem2.Bounds = new System.Drawing.Rectangle(0, 0, 752, 661);
            this.layoutControlItem2.ControlVerticalAlignment = Telerik.WinControls.UI.RadVerticalAlignment.Top;
            this.layoutControlItem2.Name = "layoutControlItem2";
            this.layoutControlItem2.Text = "";
            // 
            // radButton4
            // 
            this.radButton4.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.radButton4.Location = new System.Drawing.Point(0, 663);
            this.radButton4.Name = "radButton4";
            this.radButton4.Size = new System.Drawing.Size(754, 24);
            this.radButton4.TabIndex = 8;
            this.radButton4.Text = "Save";
            this.radButton4.Click += new System.EventHandler(this.radButton3_Click);
            // 
            // radButton6
            // 
            this.radButton6.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.radButton6.Location = new System.Drawing.Point(0, 687);
            this.radButton6.Name = "radButton6";
            this.radButton6.Size = new System.Drawing.Size(754, 24);
            this.radButton6.TabIndex = 7;
            this.radButton6.Text = "Load";
            this.radButton6.Click += new System.EventHandler(this.radButton2_Click);
            // 
            // TitleBar1
            // 
            this.TitleBar1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(62)))), ((int)(((byte)(80)))));
            this.TitleBar1.Dock = System.Windows.Forms.DockStyle.Top;
            this.TitleBar1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TitleBar1.ForeColor = System.Drawing.Color.White;
            this.TitleBar1.Location = new System.Drawing.Point(0, 0);
            this.TitleBar1.Name = "TitleBar1";
            this.TitleBar1.Size = new System.Drawing.Size(1332, 28);
            this.TitleBar1.TabIndex = 0;
            this.TitleBar1.TabStop = false;
            this.TitleBar1.Text = "radRibbonBar1";
            ((Telerik.WinControls.UI.RadTitleBarElement)(this.TitleBar1.GetChildAt(0))).Text = "radRibbonBar1";
            // 
            // object_6543ef47_badb_461b_bfc4_277c159d816a
            // 
            this.object_6543ef47_badb_461b_bfc4_277c159d816a.Name = "object_6543ef47_badb_461b_bfc4_277c159d816a";
            this.object_6543ef47_badb_461b_bfc4_277c159d816a.StretchHorizontally = true;
            this.object_6543ef47_badb_461b_bfc4_277c159d816a.StretchVertically = true;
            // 
            // layoutControlItem1
            // 
            this.layoutControlItem1.AssociatedControl = null;
            this.layoutControlItem1.Bounds = new System.Drawing.Rectangle(0, 0, 300, 30);
            this.layoutControlItem1.DisabledTextRenderingHint = System.Drawing.Text.TextRenderingHint.SystemDefault;
            this.layoutControlItem1.FitToSizeMode = Telerik.WinControls.RadFitToSizeMode.FitToParentContent;
            this.layoutControlItem1.MaxSize = new System.Drawing.Size(300, 30);
            this.layoutControlItem1.Name = "layoutControlItem1";
            this.layoutControlItem1.Text = "radButton1";
            this.layoutControlItem1.TextRenderingHint = System.Drawing.Text.TextRenderingHint.SystemDefault;
            this.layoutControlItem1.UseCompatibleTextRendering = false;
            // 
            // RadForm1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(244)))), ((int)(((byte)(247)))), ((int)(((byte)(254)))));
            this.ClientSize = new System.Drawing.Size(1332, 788);
            this.Controls.Add(this.radPageView1);
            this.Controls.Add(this.TitleBar1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "RadForm1";
            // 
            // 
            // 
            this.RootElement.ApplyShapeToControl = true;
            this.Text = "radRibbonBar1";
            ((System.ComponentModel.ISupportInitialize)(this.radPageView1)).EndInit();
            this.radPageView1.ResumeLayout(false);
            this.ProjectsPage.ResumeLayout(false);
            this.ProjectsPage.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.radDataLayout1.LayoutControl)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radDataLayout1)).EndInit();
            this.radDataLayout1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.radSeparator1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radButton3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radBindingNavigator1)).EndInit();
            this.radBindingNavigator1.ResumeLayout(false);
            this.radBindingNavigator1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.radButton1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radButton2)).EndInit();
            this.Scheduler.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.radScheduler1)).EndInit();
            this.radScheduler1.ResumeLayout(false);
            this.radScheduler1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.radSchedulerNavigator1)).EndInit();
            this.ToDoList.ResumeLayout(false);
            this.ToDoList.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.radTextBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radTextBox1)).EndInit();
            this.Team.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.radDataLayout2.LayoutControl)).EndInit();
            this.radDataLayout2.LayoutControl.ResumeLayout(false);
            this.radDataLayout2.LayoutControl.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.radDataLayout2)).EndInit();
            this.radDataLayout2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.radBindingNavigator2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radButton4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radButton6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.TitleBar1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bindingSource2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private Telerik.WinControls.UI.RadPageView radPageView1;
        private Telerik.WinControls.UI.RadPageViewPage ProjectsPage;
        private Telerik.WinControls.UI.RadTitleBar TitleBar1;
        private Telerik.WinControls.UI.RadPageViewPage Scheduler;
        private Telerik.WinControls.UI.RadPageViewPage ToDoList;
        private Telerik.WinControls.UI.RadPageViewPage Team;
        private Telerik.WinControls.RootRadElement object_6543ef47_badb_461b_bfc4_277c159d816a;
        private Telerik.WinControls.UI.RadDataLayout radDataLayout1;
        private Telerik.WinControls.UI.RadBindingNavigator radBindingNavigator1;
        private Telerik.WinControls.UI.CommandBarRowElement radBindingNavigator1RowElement;
        private Telerik.WinControls.UI.CommandBarStripElement radBindingNavigator1FirstStrip;
        private Telerik.WinControls.UI.CommandBarButton radBindingNavigator1MoveFirstItem;
        private Telerik.WinControls.UI.CommandBarSeparator commandBarSeparator1;
        private Telerik.WinControls.UI.CommandBarButton radBindingNavigator1MovePreviousItem;
        private Telerik.WinControls.UI.CommandBarSeparator commandBarSeparator2;
        private Telerik.WinControls.UI.CommandBarTextBox radBindingNavigator1PositionItem;
        private Telerik.WinControls.UI.CommandBarLabel radBindingNavigator1CountItem;
        private Telerik.WinControls.UI.CommandBarSeparator commandBarSeparator3;
        private Telerik.WinControls.UI.CommandBarButton radBindingNavigator1MoveNextItem;
        private Telerik.WinControls.UI.CommandBarSeparator commandBarSeparator4;
        private Telerik.WinControls.UI.CommandBarButton radBindingNavigator1MoveLastItem;
        private Telerik.WinControls.UI.CommandBarStripElement radBindingNavigator1SecondStrip;
        private Telerik.WinControls.UI.CommandBarButton radBindingNavigator1AddNewItem;
        private Telerik.WinControls.UI.CommandBarSeparator commandBarSeparator5;
        private Telerik.WinControls.UI.CommandBarButton radBindingNavigator1DeleteItem;
        private System.Windows.Forms.BindingSource bindingSource1;
        private Telerik.WinControls.UI.LayoutControlItem layoutControlItem1;
        private Telerik.WinControls.UI.RadButton radButton1;
        private Telerik.WinControls.UI.RadButton radButton2;
        private Telerik.WinControls.UI.RadSeparator radSeparator1;
        private Telerik.WinControls.UI.RadButton radButton3;
        private System.Windows.Forms.BindingSource bindingSource2;
        private Telerik.WinControls.UI.RadScheduler radScheduler1;
        private Telerik.WinControls.UI.RadSchedulerNavigator radSchedulerNavigator1;
        private Telerik.WinControls.UI.RadButton radButton4;
        private Telerik.WinControls.UI.RadButton radButton6;
        private Telerik.WinControls.UI.RadDataLayout radDataLayout2;
        private Telerik.WinControls.UI.RadBindingNavigator radBindingNavigator2;
        private Telerik.WinControls.UI.CommandBarRowElement radBindingNavigator2RowElement;
        private Telerik.WinControls.UI.CommandBarStripElement radBindingNavigator2FirstStrip;
        private Telerik.WinControls.UI.CommandBarButton radBindingNavigator2MoveFirstItem;
        private Telerik.WinControls.UI.CommandBarSeparator commandBarSeparator6;
        private Telerik.WinControls.UI.CommandBarButton radBindingNavigator2MovePreviousItem;
        private Telerik.WinControls.UI.CommandBarSeparator commandBarSeparator7;
        private Telerik.WinControls.UI.CommandBarTextBox radBindingNavigator2PositionItem;
        private Telerik.WinControls.UI.CommandBarLabel radBindingNavigator2CountItem;
        private Telerik.WinControls.UI.CommandBarSeparator commandBarSeparator8;
        private Telerik.WinControls.UI.CommandBarButton radBindingNavigator2MoveNextItem;
        private Telerik.WinControls.UI.CommandBarSeparator commandBarSeparator9;
        private Telerik.WinControls.UI.CommandBarButton radBindingNavigator2MoveLastItem;
        private Telerik.WinControls.UI.CommandBarStripElement radBindingNavigator2SecondStrip;
        private Telerik.WinControls.UI.CommandBarButton radBindingNavigator2AddNewItem;
        private Telerik.WinControls.UI.CommandBarSeparator commandBarSeparator10;
        private Telerik.WinControls.UI.CommandBarButton radBindingNavigator2DeleteItem;
        private Telerik.WinControls.UI.LayoutControlItem layoutControlItem2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox tbTaskDescription;
        private System.Windows.Forms.TextBox tbTaskName;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.ComboBox cmbPriority;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.RadioButton radioButton2;
        private System.Windows.Forms.RadioButton radioButton1;
        private Telerik.WinControls.UI.RadTextBox radTextBox1;
        private Telerik.WinControls.UI.RadTextBox radTextBox2;
        private System.Windows.Forms.Button button7;
    }
}